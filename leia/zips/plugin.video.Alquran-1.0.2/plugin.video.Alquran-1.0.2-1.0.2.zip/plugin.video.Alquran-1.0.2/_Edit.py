import xbmcaddon

MainBase = 'https://goo.gl/KrjmNs'
addon = xbmcaddon.Addon('plugin.video.Alquran')
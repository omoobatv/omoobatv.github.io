import xbmcaddon

MainBase = 'https://goo.gl/FB7Hou'
addon = xbmcaddon.Addon('plugin.video.naijaMovies')
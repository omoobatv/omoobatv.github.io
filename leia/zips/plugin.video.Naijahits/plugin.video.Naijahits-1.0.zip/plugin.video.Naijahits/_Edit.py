import xbmcaddon
MainBase = 'https://goo.gl/Jg9N5S'
addon = xbmcaddon.Addon('plugin.video.Naijahits')
